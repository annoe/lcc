<?php

use App\Http\Controllers\ProvinsiController;
use Illuminate\Support\Facades\Route;

Route::get('/', fn () => redirect()->route('provinsi.index'));

// ── Master Data Provinsi ──────────────────────────────────────────────────
Route::prefix('master/provinsi')->name('provinsi.')->group(function () {

    // CRUD (modal-based, tanpa halaman create/edit terpisah)
    Route::get('/',              [ProvinsiController::class, 'index'])->name('index');
    Route::post('/',             [ProvinsiController::class, 'store'])->name('store');
    Route::put('/{provinsi}',    [ProvinsiController::class, 'update'])->name('update');
    Route::delete('/{provinsi}', [ProvinsiController::class, 'destroy'])->name('destroy');

    // Export — harus sebelum /{provinsi} agar tidak ambiguous
    Route::get('/export',          [ProvinsiController::class, 'export'])->name('export');

    // Import Excel
    Route::get('/import/template', [ProvinsiController::class, 'downloadTemplate'])->name('import.template');
    Route::post('/import/preview', [ProvinsiController::class, 'importPreview'])->name('import.preview');
    Route::post('/import/save',    [ProvinsiController::class, 'importSave'])->name('import.save');
});
